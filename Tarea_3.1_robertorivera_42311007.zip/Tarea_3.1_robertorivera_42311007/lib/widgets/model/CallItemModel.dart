class CallItemModel {

  String name;
  String dateTime;

  CallItemModel(this.name, this.dateTime);

}