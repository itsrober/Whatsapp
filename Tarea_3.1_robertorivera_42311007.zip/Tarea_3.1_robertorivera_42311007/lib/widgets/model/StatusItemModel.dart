class StatusItemModel {

  String name;
  String dateTime;

  StatusItemModel(this.name, this.dateTime);

}